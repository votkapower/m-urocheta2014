-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Време на генериране:  октомври 2013 в 09:43
-- Версия на сървъра: 5.1.33
-- Версия на PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `urocheta`
--

-- --------------------------------------------------------

--
-- Структура на таблица `cats`
--

CREATE TABLE IF NOT EXISTS `cats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дъмп (схема) на данните в таблицата `cats`
--

INSERT INTO `cats` (`id`, `name`) VALUES
(1, 'PHP & MYSQL'),
(2, 'HTML & CSS & JS'),
(3, 'Дизайн'),
(4, 'Други');

-- --------------------------------------------------------

--
-- Структура на таблица `tutorials`
--

CREATE TABLE IF NOT EXISTS `tutorials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(1500) NOT NULL,
  `desc` text NOT NULL,
  `image` text NOT NULL,
  `video-url` text NOT NULL,
  `files` text NOT NULL,
  `video-type` enum('vbox','youtube','direct') NOT NULL DEFAULT 'direct',
  `cat_id` int(11) NOT NULL,
  `author` varchar(50) NOT NULL,
  `views` int(11) NOT NULL DEFAULT '0',
  `votes` int(11) NOT NULL DEFAULT '0',
  `timestamp` int(11) NOT NULL,
  `show` enum('true','false') NOT NULL DEFAULT 'true',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Дъмп (схема) на данните в таблицата `tutorials`
--

INSERT INTO `tutorials` (`id`, `title`, `desc`, `image`, `video-url`, `files`, `video-type`, `cat_id`, `author`, `views`, `votes`, `timestamp`, `show`) VALUES
(1, 'Как се прави сайт: страницата за Гледане и Каталога', 'Как се прави сайт: страницата за Гледане и КаталогаКак се прави сайт: страницата за Гледане и Каталога', 'http://i3.ytimg.com/vi/hkrGEVAbmls/mqdefault.jpg', 'http://www.youtube.com/watch?v=hkrGEVAbmls', '', 'youtube', 2, 'voTkaPoweR', 16, 3, 1381592712, 'true'),
(2, 'Как се прави сайт: слайдъра', 'Как се прави сайт: слайдъра Как се прави сайт: слайдъра Как се прави сайт: слайдъра Как се прави сайт: слайдъра', 'http://i3.ytimg.com/vi/9sZ_yXFAF6c/mqdefault.jpg', 'http://www.youtube.com/watch?v=9sZ_yXFAF6c', '', 'youtube', 2, 'voTkaPoweR', 7, 0, 1381592787, 'true'),
(3, 'Константин, Борис Дали, Илиян - Палатка ', '', 'http://i1.ytimg.com/vi/Cl9rTZn_Mv8/mqdefault.jpg', 'http://www.youtube.com/watch?v=Cl9rTZn_Mv8', '', 'youtube', 1, 'voTkaPoweR', 17, 2, 1381607910, 'true'),
(4, 'Това е тестов видо клип от vbox', '', 'http://i48.vbox7.com/i/492/492ae4e7115.jpg', 'http://vbox7.com/play:492ae4e711', '', 'vbox', 5, 'voTkaPoweR', 45, 0, 1381608656, 'true'),
(5, 'Песен на Jentaro - Разчекнати', '', 'http://i47.vbox7.com/i/f78/f78e6f65f45.jpg', 'http://media08.vbox7.com/s/f7/f78e6f65f4r3884921c2.flv', '', 'direct', 4, 'voTkaPoweR', 38, 5, 1381609401, 'true'),
(6, 'C# програмadas dasd asd', 'Съдържание:\r\n- За Телерик и софтуерната академия\r\n- Програма за обучение и работа &quot;софтуерна академия&quot;\r\n- C# курс - цели и учебна програма\r\n- Трейнърски екип', 'http://i3.ytimg.com/vi/alLYOBk5rLU/mqdefault.jpg', 'http://www.youtube.com/watch?v=alLYOBk5rLU', 'asdasdasdasdasdasd', 'youtube', 1, 'voTkaPoweR', 20, 1, 1381616086, 'true'),
(7, 'Как се прави сайт: Запознаване с дизайна, рязане и конфигурира', 'В този урок ще разгледаме два дизайна - единият е на сайта, а другият на админ панела на сайта. Ще научим някой напълни безполезни и безсмислени истории и ще нагласим папките за нашия сайт.\r\n\r\nФайловете от урока тук: http://votkapower.tk/read-25', 'http://i3.ytimg.com/vi/vQ4UpmZFAcQ/mqdefault.jpg', 'http://www.youtube.com/watch?v=vQ4UpmZFAcQ', '', 'youtube', 3, 'demo', 11, 4, 1381686894, 'true'),
(13, 'nqkaff youtbe klipp :)', 'http://www.youtube.com/watch?v=Hb9dK0WGW-g', 'http://i3.ytimg.com/vi/Hb9dK0WGW-g/mqdefault.jpg', 'http://www.youtube.com/watch?v=Hb9dK0WGW-g', '', 'youtube', 4, 'voTkaPoweR', 1, 0, 1381818543, 'true'),
(9, 'Как се прави сайт: страницата за Гледане и Каталога', 'В този урок ще видим как се прави това - като цъкнеш на някой филм и да ти отваря отделна страничка с информация за филма, който си цъкнал. Ще напрвим и една статична страничка - каталог където потребителя ще може да търси филми .', 'http://i3.ytimg.com/vi/hkrGEVAbmls/mqdefault.jpg', 'http://www.youtube.com/watch?v=hkrGEVAbmls', '', 'youtube', 2, 'demo', 2, 0, 1381775769, 'true'),
(10, 'Offroad moto competition in Spain - Red Bull Give Me Five 2013', 'Offroad moto competition in Spain - Red Bull Give Me Five 2013', 'http://i3.ytimg.com/vi/KN7U5wZoQ6A/mqdefault.jpg', 'http://www.youtube.com/watch?v=KN7U5wZoQ6A', '', 'youtube', 2, 'demo', 2, 1, 1381776392, 'true'),
(11, 'Рускиня няма страх от високо!', 'Рускиня няма страх от високо!', 'm', 'http://vbox7.com/play:6a8c2d3d42', '', 'vbox', 2, 'demo', 2, 0, 1381776599, 'true'),
(12, 'Bodybuilding Motivation - When The Real Work Comes..', 'Bodybuilding Motivation - When The Real Work Comes..', 'm', 'http://vbox7.com/play:m3ed3ff31c', '', 'vbox', 2, 'demo', 1, 0, 1381776727, 'true');

-- --------------------------------------------------------

--
-- Структура на таблица `tutorials-comments`
--

CREATE TABLE IF NOT EXISTS `tutorials-comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `new` enum('true','false') NOT NULL DEFAULT 'true',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Дъмп (схема) на данните в таблицата `tutorials-comments`
--

INSERT INTO `tutorials-comments` (`id`, `video_id`, `username`, `comment`, `timestamp`, `new`) VALUES
(3, 5, 'demo', 'Проба', 1381686588, 'false'),
(2, 4, 'voTkaPoweR', 'mnogo tupp klip brat.. naiistinaa :D', 1381613138, 'false'),
(7, 3, 'voTkaPoweR', 'Ахаха .. ахха .. многоо якк клипп ..направо се разревах .. :D :D', 1381704252, 'false'),
(6, 5, 'voTkaPoweR', 'Не е лош сайта а ? :D', 1381703346, 'false'),
(8, 5, 'M1tq', 'Ами, според мене .. е идеаленн :Д', 1381744083, 'true'),
(9, 3, 'voTkaPoweR', 'ГОлямаа песенн ейй .. :D', 1381744201, 'true'),
(10, 3, 'voTkaPoweR', 'да е.. мн весело сайтче .. като цяло де ;d', 1381744246, 'true'),
(12, 5, 'demo', 'Екстра е', 1381776192, 'true');

-- --------------------------------------------------------

--
-- Структура на таблица `user-pms`
--

CREATE TABLE IF NOT EXISTS `user-pms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tema` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `from-user` varchar(50) NOT NULL,
  `to-user` varchar(50) NOT NULL,
  `readed` enum('true','false') NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Дъмп (схема) на данните в таблицата `user-pms`
--

INSERT INTO `user-pms` (`id`, `tema`, `msg`, `from-user`, `to-user`, `readed`, `timestamp`) VALUES
(9, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>demo</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=9''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381776333),
(7, 'Новот харесване твоя урок Песен на Jentaro - Разчекнати..', '\r\n	Здравей,\r\n	\r\n	  <b>demo</b>, току що ти изгледа и хареса урока <a href=''./?p=view&id=5''>Песен на Jentaro - Разчекнати..</a> :)\r\n	  \r\n	 * това е системно съобщение - моля, не отговаряйте.\r\n	 \r\n	 Поздрави,\r\n	  от Екипа на сайта.\r\n	', 'system', 'voTkaPoweR', 'true', 1381776173),
(8, 'Нов коментар на урок Песен на Jentaro - Разчекнати..', '\r\n						Здравей,\r\n						\r\n						  <a  href=''./?p=profile&u=demo''>demo</a>, току що ти изгледа и <a href=''./?p=view&id=5\\&quot;''>коментира урока</a>. Цъкни <a href=''./?p=view&id=5\\&quot;''>тук</a> за да видиш коментара :)\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', 'voTkaPoweR', 'true', 1381776192),
(10, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>demo</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=10''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381776403),
(12, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>demo</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=10''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381776547),
(13, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>demo</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=11''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381776613),
(14, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>demo</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=11''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381776683),
(15, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>demo</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=12''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381776737),
(16, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>voTkaPoweR</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=2''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381815716),
(17, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>voTkaPoweR</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=12''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', '', 'false', 1381815718),
(18, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>voTkaPoweR</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=2''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', 'voTkaPoweR', 'true', 1381815775),
(19, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>voTkaPoweR</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=12''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', 'demo', 'false', 1381815776),
(20, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>voTkaPoweR</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=6''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', 'voTkaPoweR', 'true', 1381818551),
(21, 'Урока ти е уробрен !', '\r\n						Здравей,\r\n						\r\n						 Админ <b>voTkaPoweR</b> ти удобри урока и вече всички могат да го гледат, коментират и харесват. \r\n						 \r\n						 Линк до урока:  <a href=''./?p=view&id=13''>натисни тук</a>.\r\n						  \r\n						 * това е системно съобщение - моля, не отговаряйте.\r\n						 \r\n						 Поздрави,\r\n						  от Екипа на сайта.\r\n						', 'system', 'voTkaPoweR', 'true', 1381818551);

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(150) NOT NULL,
  `sex` enum('1','2') NOT NULL,
  `years` int(11) NOT NULL,
  `desc` varchar(500) NOT NULL,
  `website` varchar(100) NOT NULL,
  `avatar` text NOT NULL,
  `timestamp` int(11) NOT NULL,
  `tutorials` int(11) NOT NULL,
  `rank` enum('user','admin') NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дъмп (схема) на данните в таблицата `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `sex`, `years`, `desc`, `website`, `avatar`, `timestamp`, `tutorials`, `rank`) VALUES
(7, 'test_potrebitel', '4684f12ed0d761bde25019e6ded95dec', 'test_potrebitel@abv.bg', '1', 0, '', '', './img/no_avatar_big.jpg', 1381703414, 0, 'user'),
(8, 'demo', 'fe01ce2a7fbac8fafaed7c982a04e229', 'demo@abv.bg', '1', 17, 'опаааа', '', 'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcRh7jct_hGfY3_T5_YbzhzBA583_K8dByF0XxY6HidZNHzHpRRzwA', 1381775054, 4, 'admin');

-- --------------------------------------------------------

--
-- Структура на таблица `vote_ips`
--

CREATE TABLE IF NOT EXISTS `vote_ips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_ip` varchar(100) NOT NULL,
  `video_id` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;
 